 <?php
 	echo "id_usuario: ".$_SESSION['id_usuario'];
?>